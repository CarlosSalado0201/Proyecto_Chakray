package com.mx.ProyectoChakray;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoChakrayApplicationTests {

	@Test
	void contextLoads() {
	}

}
